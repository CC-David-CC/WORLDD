"""Explicit focused retry plan. Dry run emits commands before execution."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys

ROOT = Path('/home/dflanag3/spatial-qualification/m06-host-session-run03-20261012-01')
HOST = socket.gethostname().split('.')[0]
assert HOST in ('sb16', 'sb16-2')
SOURCE = ROOT / 'source/spatial-os-luna-handoff'
OUTPUT = ROOT / 'evidence/focused-03'
BACKENDS = json.loads((ROOT / 'evidence/backend-dependency-verification.json').read_text())['backend']
ENV_KEYS = ('PYTHONPATH', 'SPATIAL_TEST_XSERVER', 'SPATIAL_SECURITY_EVIDENCE',
            'SPATIAL_SCOPE_EVIDENCE', 'ASAN_OPTIONS', 'UBSAN_OPTIONS')
RESOURCE_TESTS = (
    ('session-application', 'test_session_application.py'),
    ('session-dependent-cleanup', 'test_dependent_cleanup.py'),
    ('session-coordinator-retirement', 'test_coordinator_retirement.py'),
    ('session-broker-cleanup', 'test_session_broker_cleanup.py'),
    ('session-broker-retirement', 'test_broker_retirement.py'),
    ('session-stopped-broker-dependency', 'test_stopped_broker_dependency.py'),
    ('session-deferred-fence', 'test_deferred_fence.py'),
    ('session-replacement', 'test_session_replacement.py'),
    ('session-broker-replacement', 'test_broker_replacement.py'),
)


def profile_environment(profile):
    artifacts = ROOT / 'artifacts' / (profile + '-on')
    view = OUTPUT / (profile + '-native-evidence')
    env = dict(PYTHONPATH=str(artifacts / 'python') + ':' + str(SOURCE),
               SPATIAL_TEST_XSERVER=BACKENDS['Debug' if profile == 'debug' else 'ASan-UBSan']['wrapper'],
               SPATIAL_SECURITY_EVIDENCE=str(view), SPATIAL_SCOPE_EVIDENCE=str(view),
               ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',
               UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    return artifacts, env


def delegated(profile, name, command, env):
    unit = 'spatial-host-session-r03c-' + HOST + '-' + profile + '-' + name
    keys = ENV_KEYS
    return ['systemd-run', '--user', '--wait', '--pipe', '--collect', '--unit=' + unit,
            '--property=Delegate=yes', '--property=RuntimeMaxSec=1200', '--property=TimeoutStopSec=5s',
            *['--setenv=' + key + '=' + env[key] for key in keys], *command]


def plan():
    suites = []
    for profile in ('debug', 'asan'):
        artifacts, env = profile_environment(profile)
        arguments = [str(SOURCE), *[str(artifacts / name) for name in (
            'spatial-authority-launch-probe', 'spatial-security-auth', 'identityd', 'spatial-issuer-client')]]
        if profile == 'asan':
            command = [sys.executable, str(SOURCE / 'tests/native/test_host_session_production.py'),
                       *arguments, str(artifacts / 'spatial-host-session')]
            suites.insert(0, dict(profile=profile, suite='production-native', expected_tests=24,
                                 command=delegated(profile, 'production', command, env), environment=env))
        for name, file in (
            ('host-actor-controller-native', 'test_host_actor_controller.py'),
            ('session-world', 'test_session_world.py'), ('session-broker', 'test_session_broker.py')):
            command = [sys.executable, str(SOURCE / 'tests/native' / file), *arguments]
            suites.append(dict(profile=profile, suite=name, command=delegated(profile, name, command, env), environment=env))
        for name, file in RESOURCE_TESTS:
            command = [sys.executable, str(SOURCE / 'tools/with_resource_delegate.py'), '--native', '--',
                       sys.executable, str(SOURCE / 'tools/with_adapter_resources.py'), '--']
            command += [sys.executable, str(SOURCE / 'tests/native' / file), *arguments]
            suites.append(dict(profile=profile, suite=name, command=command, environment=env))
        suites.append(dict(profile=profile, suite='supervisor-session-exit', command=[sys.executable,
            str(SOURCE / 'tests/core/test_session_launch_exit.py'), str(artifacts / 'spatial-session-launch-exit-probe')], environment=env))
    assert len(suites) == 27
    assert sum(s['suite'] == 'production-native' for s in suites) == 1
    assert suites[0]['suite'] == 'production-native' and suites[0]['profile'] == 'asan'
    assert not any('startup' in s['suite'] for s in suites)
    return suites


selected = plan()
ambient = {key: os.environ.get(key, 'ABSENT') for key in (
    'LSAN_OPTIONS', 'LD_LIBRARY_PATH', 'LIBGL_DRIVERS_PATH', '__EGL_VENDOR_LIBRARY_FILENAMES',
    'SPATIAL_SECURITY_TEST_CORE_ONLY', 'SPATIAL_TEST_BROKER_CONFIG')}
assert ambient['SPATIAL_TEST_BROKER_CONFIG'] == 'ABSENT'
assert ambient['SPATIAL_SECURITY_TEST_CORE_ONLY'] == 'ABSENT'
prepared = {'suites': selected, 'ambient_graphics_environment': ambient, 'backend': BACKENDS,
            'scope': 'GLX enabled. Qualified M06 wrapper pins patched Mesa dependency closure. Raw-system-Mesa failures remain preserved.',
            'reused_passes': 'OFFstartup20 and Debugnative48 from focused01. No duplicate execution credit.'}
if sys.argv[1:] == ['--dry-run']:
    (ROOT / 'evidence/focused03-plan.json').write_text(json.dumps(prepared, indent=2) + '\n')
    print(json.dumps(prepared, indent=2))
    raise SystemExit(0)
assert not sys.argv[1:]
assert prepared == json.loads((ROOT / 'evidence/focused03-plan.json').read_text()), 'Runtime plan differs from preflight'


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def run_suite(entry):
    entry = dict(entry, started=stamp())
    stem = OUTPUT / (entry['profile'] + '-' + entry['suite'])
    env = dict(os.environ, **entry['environment'])
    Path(env['SPATIAL_SECURITY_EVIDENCE']).mkdir(exist_ok=True)
    stem.with_suffix('.command.json').write_text(json.dumps(entry, indent=2) + '\n')
    print(json.dumps({'event': 'start', 'profile': entry['profile'], 'suite': entry['suite']}), flush=True)
    log_path = stem.with_suffix('.log')
    with log_path.open('wb') as log:
        process = subprocess.Popen(entry['command'], stdout=log, stderr=subprocess.STDOUT, env=env, cwd=ROOT)
        entry['pid'] = process.pid
        stem.with_suffix('.process.json').write_text(json.dumps(entry, indent=2) + '\n')
        code = process.wait()
    data = log_path.read_text(errors='replace')
    counts = re.findall(r'Ran (\d+) tests? in ', data)
    summaries = re.findall(r'^(?:OK(?: \(.*\))?|FAILED \(.*\))$', data, re.MULTILINE)
    markers = [word for word in ('AddressSanitizer', 'LeakSanitizer', 'runtime error:') if word in data]
    skipped = sum(map(int, re.findall(r'OK \(skipped=(\d+)\)', data)))
    count = sum(map(int, counts))
    good = code == 0 and count > 0 and bool(summaries) and all(s == 'OK' for s in summaries) and not markers and not skipped
    if entry.get('expected_tests'):
        good = good and count == entry['expected_tests']
    entry.update(exit=code, finished=stamp(), tests=count, summaries=summaries,
                 sanitizer_markers=markers, skipped=skipped, log=str(log_path), status='PASS' if good else 'FAIL')
    stem.with_suffix('.exit').write_text(str(code) + '\n')
    stem.with_suffix('.result.json').write_text(json.dumps(entry, indent=2) + '\n')
    print(json.dumps({'event': 'finish', 'profile': entry['profile'], 'suite': entry['suite'],
                      'status': entry['status'], 'exit': code, 'tests': count}), flush=True)
    return good, entry


OUTPUT.mkdir()
(OUTPUT / 'selected-checks.json').write_text(json.dumps(prepared, indent=2) + '\n')
(OUTPUT / 'environment-comparison.json').write_bytes((ROOT / 'evidence/focused03-environment-comparison.json').read_bytes())
(OUTPUT / 'started.txt').write_text(stamp() + '\n')
results = []
code = 1
try:
    for selected_entry in selected:
        good, entry = run_suite(selected_entry)
        results.append(entry)
        (OUTPUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        if not good:
            break
    else:
        code = 0
finally:
    (OUTPUT / 'runner.exit').write_text(str(code) + '\n')
    (OUTPUT / 'finished.txt').write_text(stamp() + '\n')
raise SystemExit(code)
