"""Verify and extract frozen qualification artifacts on an assigned runtime host."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import socket
import subprocess
import tarfile

ROOT = Path('/home/dflanag3/spatial-qualification/m06-host-session-run03-20261012-01')
HOST = socket.gethostname().split('.')[0]
assert HOST in ('sb16', 'sb16-2')
EXPECTED = {
    'source.tar.gz': 'fbbac8ec8cf553efa343c502dc5b181e8e1425b9d25106c61c5cd344e8bb04a4',
    'debug-off.tar.gz': '38ec29211951007387507585d074af265cba4254a55c16bb55be969c8aa125f1',
    'debug-on.tar.gz': 'e83ddd0d02b812d2a3862c3692c188d339adcfa7be81c340ecb3500034c72fcd',
    'asan-off.tar.gz': 'e169643f6a49e999177d99a8a6b3c315ea7a92c04f1e53fbbea3ba726d34944f',
    'asan-on.tar.gz': '30734514ff86f455c972c25536f58612e9402aca2294493e8110cc6904001c96',
}


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


record = {'host': HOST, 'archives': {}, 'files': {}, 'backend': {}, 'runtime': 'UNRUN'}
for name, expected in EXPECTED.items():
    archive = ROOT / 'incoming' / name
    actual = digest(archive)
    assert actual == expected, (name, actual, expected)
    record['archives'][name] = actual
assert json.loads((ROOT / 'incoming/archive-manifest.json').read_text()) == EXPECTED
for name in EXPECTED:
    with tarfile.open(ROOT / 'incoming' / name, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name)
            assert not parts.is_absolute() and '..' not in parts.parts and member.isfile()
            path = ROOT / member.name
            assert path.resolve().is_relative_to(ROOT) and not path.exists(), member.name
            path.parent.mkdir(parents=True, exist_ok=True)
            with archive.extractfile(member) as source, path.open('xb') as target:
                for chunk in iter(lambda: source.read(1024 * 1024), b''):
                    target.write(chunk)
            path.chmod(member.mode & 0o777)
for prefix in ('source', 'debug-off', 'debug-on', 'asan-off', 'asan-on'):
    base = ROOT / 'source' if prefix == 'source' else ROOT / 'artifacts' / prefix
    manifest = json.loads((ROOT / 'incoming' / (prefix + '-manifest.json')).read_text())
    for name, expected in manifest.items():
        assert digest(base / name) == expected, (prefix, name)
    record['files'][prefix] = len(manifest)

source = ROOT / 'source/spatial-os-luna-handoff'
qualified = Path('/home/dflanag3/src/spacial_desktop-m06-20261012/spatial-os-luna-handoff')
effective = qualified / 'local/xlibre-patched/24653f6b961a77f03f321b64343200ef0d227e1b52e39ff83cda48d9934788e2/source'
for profile, subdir, expected in (
    ('Debug', 'build', 'dfd97979fc6363ad841bddc58a6884a1461aed1c83aa2cd9bfea9c4293ebe623'),
    ('ASan-UBSan', 'build-sanitize', '7a295f8b2d0b8a81a05488baedf806297462089a6b925d9e36b5c526389fd0de'),
):
    receipt_path = qualified / 'local/m06-scoped-input-05' / profile / 'server-build/run.json'
    receipt = json.loads(receipt_path.read_text())
    assert len(receipt['extension_sources']) == 20
    for name, sha in receipt['extension_sources'].items():
        assert digest(source / name) == sha, ('candidate extension source', name)
        assert digest(qualified / name) == sha, ('qualified extension source', name)
    server = effective / subdir / 'hw/vfb/Xvfb'
    assert digest(server) == expected
    record['backend'][profile] = {'binary': str(server), 'sha256': expected,
                                  'extension_inputs': 20, 'receipt_sha256': digest(receipt_path)}
for profile in ('debug-off', 'debug-on', 'asan-off', 'asan-on'):
    executable = ROOT / 'artifacts' / profile / 'spatial-host-session'
    dependency = subprocess.run(['ldd', str(executable)], capture_output=True, text=True, check=True)
    assert 'not found' not in dependency.stdout, dependency.stdout
(ROOT / 'evidence/deployment-verification.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
