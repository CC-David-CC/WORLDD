#!/usr/bin/env bash
python3 /home/dflanag3/spatial-qualification/m06-host-session-run03-20261012-01/run-host-session-focused.py > /home/dflanag3/spatial-qualification/m06-host-session-run03-20261012-01/evidence/runner.log 2>&1
result=$?
printf "%s\n" "$result" > /home/dflanag3/spatial-qualification/m06-host-session-run03-20261012-01/evidence/launcher.exit
exit "$result"
