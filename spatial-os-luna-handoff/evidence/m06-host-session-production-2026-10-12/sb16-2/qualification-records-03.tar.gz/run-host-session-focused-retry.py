"""Run the selected frozen host-session checks. No compilation or source edits."""
import datetime
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys

ROOT = Path('/home/dflanag3/spatial-qualification/m06-host-session-run03-20261012-01')
HOST = socket.gethostname().split('.')[0]
assert HOST in ('sb16', 'sb16-2')
SOURCE = ROOT / 'source/spatial-os-luna-handoff'
OUTPUT = ROOT / 'evidence/focused-02'
OUTPUT.mkdir()
RESULTS = []
BACKENDS = json.loads((ROOT / 'evidence/deployment-verification.json').read_text())['backend']
RESOURCES = (
    ('session-application', 'test_session_application.py'),
    ('session-dependent-cleanup', 'test_dependent_cleanup.py'),
    ('session-coordinator-retirement', 'test_coordinator_retirement.py'),
    ('session-broker-cleanup', 'test_session_broker_cleanup.py'),
    ('session-broker-retirement', 'test_broker_retirement.py'),
    ('session-stopped-broker-dependency', 'test_stopped_broker_dependency.py'),
    ('session-deferred-fence', 'test_deferred_fence.py'),
    ('session-replacement', 'test_session_replacement.py'),
    ('session-broker-replacement', 'test_broker_replacement.py'),
)


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def run_suite(profile, name, command, environment):
    stem = OUTPUT / (profile + '-' + name)
    log_path = stem.with_suffix('.log')
    entry = {'profile': profile, 'suite': name, 'started': stamp(), 'command': command}
    stem.with_suffix('.command.json').write_text(json.dumps(entry, indent=2) + '\n')
    print(json.dumps({'event': 'start', 'profile': profile, 'suite': name}), flush=True)
    with log_path.open('wb') as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=environment, cwd=ROOT)
        entry['pid'] = process.pid
        stem.with_suffix('.process.json').write_text(json.dumps(entry, indent=2) + '\n')
        code = process.wait()
    data = log_path.read_text(errors='replace')
    count = re.findall(r'Ran (\d+) tests? in ', data)
    summary = re.findall(r'^(?:OK(?: \(.*\))?|FAILED \(.*\))$', data, re.MULTILINE)
    diagnostics = [word for word in ('AddressSanitizer', 'LeakSanitizer', 'runtime error:') if word in data]
    skipped = re.findall(r'OK \(skipped=(\d+)\)', data)
    entry.update({'exit': code, 'finished': stamp(), 'tests': sum(map(int, count)),
                  'summaries': summary, 'sanitizer_markers': diagnostics,
                  'skipped': sum(map(int, skipped)), 'log': str(log_path)})
    good = code == 0 and bool(count) and not diagnostics and not skipped and bool(summary) and all(s == 'OK' for s in summary)
    entry['status'] = 'PASS' if good else 'FAIL'
    stem.with_suffix('.exit').write_text(str(code) + '\n')
    stem.with_suffix('.result.json').write_text(json.dumps(entry, indent=2) + '\n')
    RESULTS.append(entry)
    (OUTPUT / 'results.json').write_text(json.dumps(RESULTS, indent=2) + '\n')
    print(json.dumps({'event': 'finish', 'profile': profile, 'suite': name,
                      'status': entry['status'], 'exit': code, 'tests': entry['tests']}), flush=True)
    return good


def environment(profile):
    artifacts = ROOT / 'artifacts' / (profile + '-on')
    backend = BACKENDS['Debug' if profile == 'debug' else 'ASan-UBSan']['binary']
    witness = OUTPUT / (profile + '-native-evidence')
    witness.mkdir()
    env = dict(os.environ, PYTHONPATH=str(artifacts / 'python') + ':' + str(SOURCE),
               SPATIAL_TEST_XSERVER=backend, SPATIAL_SECURITY_EVIDENCE=str(witness),
               SPATIAL_SCOPE_EVIDENCE=str(witness),
               ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',
               UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    assert not env.get('SPATIAL_TEST_BROKER_CONFIG'), 'Use the reviewed resource launcher for an inherited resource policy'
    if profile == 'asan':
        env['SPATIAL_SECURITY_TEST_CORE_ONLY'] = '1'
    return artifacts, env


def delegated(profile, name, command, env):
    unit = 'spatial-host-session-r03b-' + HOST + '-' + profile + '-' + name
    return ['systemd-run', '--user', '--wait', '--pipe', '--collect', '--unit=' + unit,
            '--property=Delegate=yes', '--property=RuntimeMaxSec=1200', '--property=TimeoutStopSec=5s',
            *['--setenv=' + key + '=' + env[key] for key in (
                'PYTHONPATH', 'SPATIAL_TEST_XSERVER', 'SPATIAL_SECURITY_EVIDENCE',
                'ASAN_OPTIONS', 'UBSAN_OPTIONS')],
            *(['--setenv=SPATIAL_SECURITY_TEST_CORE_ONLY=1'] if env.get('SPATIAL_SECURITY_TEST_CORE_ONLY') == '1' else []), *command]


def execute():
    contexts = {profile: environment(profile) for profile in ('debug', 'asan')}
    for profile in ('asan',):
        artifacts, env = contexts[profile] = environment(profile)
        off = ROOT / 'artifacts' / (profile + '-off')
        startup_env = dict(env, PYTHONPATH=str(off / 'python') + ':' + str(SOURCE))
        if not run_suite(profile, 'off-startup', [sys.executable,
                str(SOURCE / 'tests/core/test_host_session_startup.py'),
                str(off / 'spatial-host-session'), str(off / 'python')], startup_env):
            return 1
        assert RESULTS[-1]['tests'] == 5, RESULTS[-1]
    for profile in ('debug', 'asan'):
        artifacts, env = contexts[profile]
        arguments = [str(SOURCE), *[str(artifacts / name) for name in (
            'spatial-authority-launch-probe', 'spatial-security-auth', 'identityd', 'spatial-issuer-client')]]
        command = [sys.executable, str(SOURCE / 'tests/native/test_host_session_production.py'),
                   *arguments, str(artifacts / 'spatial-host-session')]
        if not run_suite(profile, 'production-native', delegated(profile, 'production', command, env), env):
            return 1
        assert RESULTS[-1]['tests'] == 24, RESULTS[-1]
    for profile in ('debug', 'asan'):
        artifacts, env = contexts[profile]
        arguments = [str(SOURCE), *[str(artifacts / name) for name in (
            'spatial-authority-launch-probe', 'spatial-security-auth', 'identityd', 'spatial-issuer-client')]]
        for name, file in (
            ('host-actor-controller-native', 'test_host_actor_controller.py'),
            ('session-world', 'test_session_world.py'), ('session-broker', 'test_session_broker.py')):
            command = [sys.executable, str(SOURCE / 'tests/native' / file), *arguments]
            if not run_suite(profile, name, delegated(profile, name, command, env), env):
                return 1
        for name, file in RESOURCES:
            command = [sys.executable, str(SOURCE / 'tools/with_resource_delegate.py'), '--native', '--',
                       sys.executable, str(SOURCE / 'tools/with_adapter_resources.py'), '--',
                       *(['env', 'SPATIAL_SECURITY_TEST_CORE_ONLY=1'] if profile == 'asan' else []),
                       sys.executable, str(SOURCE / 'tests/native' / file), *arguments]
            if not run_suite(profile, name, command, env):
                return 1
        if not run_suite(profile, 'supervisor-session-exit', [sys.executable,
                str(SOURCE / 'tests/core/test_session_launch_exit.py'),
                str(artifacts / 'spatial-session-launch-exit-probe')], env):
            return 1
    return 0


(OUTPUT / 'selected-checks.txt').write_text(
    'Reuse focused01 OFF startup20 and Debug native48 PASS. Rerun ASan native24 perhost with GLX disabled.\n'
    'Then UNRUN Debug and ASan host controller, session world/broker, application/cleanup/retirement/replacement callers.\n'
    'Use declared user-delegate or resource/adapter wrappers per suite. Stop on a failed suite.\n'
    'No source edits, builds, milestone gate claims, or physical-input claims. ASan core-only mode excludes GLX coverage.\n')
(OUTPUT / 'environment-comparison.json').write_bytes((ROOT / 'evidence/focused02-environment-comparison.json').read_bytes())
(OUTPUT / 'started.txt').write_text(stamp() + '\n')
code = 1
try:
    code = execute()
finally:
    (OUTPUT / 'runner.exit').write_text(str(code) + '\n')
    (OUTPUT / 'finished.txt').write_text(stamp() + '\n')
raise SystemExit(code)
